Created during the course MTAT.03.138 Software Project at University of Tartu

Guidelines on how to use the application, how to write operator and macro declarations can be found on Github
It is really suggested to follow the tutorial for the first time
https://github.com/Abercus/LaTeXEE/wiki/4.-iteration-tutorial

What is the application?

The customer had a plan for a series of applications involving LaTeX formulas � for the purposes of refactoring, style/type checking etc. All of these tasks require the parsing of the LaTeX document and representing the mathematical formulas in a machine-readable data structure. The purpose of LaTeXEE application is to parse the document and create such a data structure.

The application uses special \declare commands, which is not by default a part of LaTeX. \declare is used  to declare macros and operators which may appear in the documents.
In order to use the \declare commands declmath.sty had to be included, which allowed to create a similar declaration language, but which was much more uncomfortable.

What can it do?

The application parses the input LaTeX file and outputs either in Openmath XML (http://www.openmath.org/) or Popcorn format (http://java.symcomp.org/FormalPopcorn.html). Also supports checking for ambiguity in declarations.

Good showcase of the application is in folder valid_latex_example.

C:\Demo\>java -jar LaTeXEE.jar valid_latex_example/val
idlatex.tex -o output.xml
Outputfile is: output.xml
3/3 declarations parsed successfully.
2/2 formulas parsed successfully.


How does it do it?

1) Input LaTeX document with macro and operator declarations is read.
2) Input document is parsed into document parse tree.
3) From document parse tree declarations of macros, declarations of operators and formulas are gathered.
4) Using objects gathered in phase 3 ANTLR grammar is generated for each formula.
5) Generated ANTLR grammar is compiled on runtime.
6) Using the compiled ANTLR grammar the formulas are parsed
7) Parsed formulas are output to a file in either Popcorn or XML format

Running the program (if NullPointerException scroll down to FAQ):

Commented sample input files are located in folder examples. A lot more examples are available on the project's Github https://github.com/Abercus/LaTeXEE.

Usage: java -jar LaTeXEE.jar inputFile.tex -o outputFile.xml (flags)

1) Running example file examples/easy_example.tex, giving an output in file easy_output.xml
java -jar LaTeXEE.jar examples/easy_example.tex -o easy_output.xml -v

2) Running example file examples/scoping_example.tex, giving an output in file scoping_output.xml
java -jar LaTeXEE.jar examples/scoping_example.tex -o scoping_output.xml -v -p

3) Running larger example examples/basic_with_nonsemantic.tex with non-semantic data
java -jar LaTeXEE.jar examples/basic_with_nonsemantic.tex -o basic_with_nonsemantic_output.xml -v

Flags:
"-o filename" - change output filename
"-h" - help
"-v" - terminal output more verbose
"-a" - finds possible ambiguous declares.
"-A" - ambiguity checker with priorities
"-p" - output in popcorn
"-t" - prints  syntax tree


FAQ:

Q: I'm getting a NullPointerException when running the program?
A: Because the application relies on runtime compiling it is required to have JDK installed and configured correctly.

Solution (Windows):
1) Install Java SE Development Kit 8 (http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads- 2133151.html)
2) Add JDK 8 bin to System Variables

Q: Formula with spaces are not parsed?
A: As of the moment formulas, containing spaces, are not supported, project was more about proving different concepts than adding such stuff.

Q: X feature of LaTeX is not supported?
A: This project was meant to be a proof of concept and a exploratory project.

Q: The license?
A: This project is under MIT license.